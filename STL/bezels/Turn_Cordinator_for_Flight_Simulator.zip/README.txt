                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2613145
Turn Cordinator for Flight Simulator by alvaroalea is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Stick and Ball Gauge for use in panel of GA Flight Simulators.
It's need 2 servos of 9gr. like SG90, and will be conected to the PC with the flight simulator via OpenCockpits Servo Board, a Arduino or similar system.

Please, be aware that depend of the branch of servos, you may need to modifi fondo4.stl or put some separator on the servos screws.

ring.stl is a optional piece in case you want to put a glass or plastic and the thick of panel is not enought.

You need to print acople_servo.stl twice, but only need to print one of avion1.stl or avion2.stl

You need several 4 M3 screws and nuts for fix the pieces and the instrument to the panel.

Print, glue and cut the background image over fondo2.stl and fondo3.stl, as show in the picture.

use white PLA for fondo4, or glue a white piece of paper for the ball background.

It's a modification of my other gauges, bezel and other piezes can be shared, so check my other gauges for change the style of the gauge.