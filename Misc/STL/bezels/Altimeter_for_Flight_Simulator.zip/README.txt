                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2744359
Altimeter for Flight Simulator by alvaroalea is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Several options are available, with left or right knob, with one or two windows for kosslman and with barber pole indication below 10K feet or 16K feet.

I use several M3 screws and nuts. and small ones for knob, encoder and reinforcement.
A 3mm Axis and 2 brass tube, one 4 mm and the other 5 mm for the axis of the needles.
and a 2mm axis for auxliar gears.

I personally drill the holes of the gear biggers for the optical sensor, but only after mount everything. I glue the emiter an receiver of the sensor with hot-glue.

I get it from a old mouse, It is a diode and a photo-diode.

Motor is a 24BJY, it is small than 28BJY but same conections, it has 0.25 rpm and 4096 half-step by revolution. it cost more or less the same than 28BJY

You can conect to FS X via FS2Link, in this link there is the source code for the arduino:
https://github.com/alvaroalea/flightsimulator/tree/master/altimetro_v0.2